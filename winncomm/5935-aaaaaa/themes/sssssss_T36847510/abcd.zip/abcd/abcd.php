<?php
/*
Plugin Name: abcd
Plugin URI: http://kddddddd.dd
Description: ABCD
Version: 1.7
Author: ABCD
Author URI: http://dddddd.ci/
*/

  require_once( 'WinnRepoabcdPluginUpdater.php' );
  new WinnRepoabcdPluginUpdater( 'http://localhost/WinnRepo/WinnRipo/', 'P30780423', __FILE__ );
       