<?php
/*
Plugin Name: Test Plugin Update
Plugin URI: http://konstruktors.com/blog/
Description: Test plugin updates
Version: 1.6
Author: Kaspars Dambis
Author URI: http://konstruktors.com/blog/
*/


/*
// TEMP: Enable update check on every request. Normally you don't need this! This is for testing only!
set_site_transient('update_plugins', null);

// TEMP: Show which variables are being requested when query plugin API
add_filter('plugins_api_result', 'aaa_result', 10, 3);
function aaa_result($res, $action, $args) {
	print_r($res);
	return $res;
}
*/
//http://localhost/WinnRepo/WinnRipo/plugin_updater_server/P43852322
require_once( 'WinnRepotestpluginupdatePluginUpdater.php' );
new WinnRepotestpluginupdatePluginUpdater( 'http://localhost/WinnRepo/WinnRipo/plugin_updater_server/P32019924');
  
  
   



// $api_url = 'http://api.damb.is/';
// $plugin_slug = basename(dirname(__FILE__));


